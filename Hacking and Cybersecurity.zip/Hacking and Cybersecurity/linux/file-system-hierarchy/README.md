# A Guide to the Linux File System
This is a project that will take a long while, but essentially what I'm going to do is I'm going to map out all the major Linux folders so you can navigate them better.

# What is the Purpose of a File System?

# /bin
The _/bin_ folder contains all the system [binaries](https://whatis.techtarget.com/definition/binary-file).

# Welcome to Linux!

## What is Linux?

## What is the terminal?

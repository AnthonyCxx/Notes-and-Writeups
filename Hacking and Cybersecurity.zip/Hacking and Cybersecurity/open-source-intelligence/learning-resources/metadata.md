# What is metadata?

[Return to main folder](https://github.com/hpu-panthersec/cyber-comp-materials/tree/main/log-analysis): log analysis main folder

# An Archive of Log Formats

| Company / Standard | Link |
| ------------------ | ---- |
| Amazon Web Service (AWS) Log Format | [AWS Format](https://docs.aws.amazon.com/AmazonS3/latest/userguide/LogFormat.html) |

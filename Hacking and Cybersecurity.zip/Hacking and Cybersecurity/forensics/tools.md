https://github.com/zed-0xff/zsteg - zsteg - detect hidden data in images <br />
https://stylesuxx.github.io/steganography/ - online steg decoder
